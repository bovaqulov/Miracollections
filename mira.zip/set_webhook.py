import telebot

TOKEN = '6922700444:AAFgl8vlLcRnryOWiHI5nV5JCkZN5wFzFPk'

WEBHOOK_URL = 'https://803b-2a05-45c2-3018-a800-5124-7503-bb1b-e644.ngrok-free.app'

bot = telebot.TeleBot(TOKEN)

bot.remove_webhook()
bot.set_webhook(url=WEBHOOK_URL)
